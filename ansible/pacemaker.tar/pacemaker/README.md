TODO:
ansible playbook that deploys corosync+pacemaker on targeted servers
